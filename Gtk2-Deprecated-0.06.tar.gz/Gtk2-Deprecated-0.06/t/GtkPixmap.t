use Gtk2::TestHelper tests => 5;
use Gtk2::Deprecated;


our @eyes_xpm = (
'16 16 3 1',
' 	c None',
'.	c #000000',
'+	c #FFFFFF',
'+++..++++++..+++',
'++.++.++++.++.++',
'+.++++.++.++++.+',
'+.++++.++.++++.+',
'.++++....++++...',
'.+++.....+++....',
'.+++.....+++....',
'.+++.....+++....',
'.+++.....+++....',
'.+++.....+++....',
'.+++.....+++....',
'.++++....++++...',
'+.++++.++.++++.+',
'+.++++.++.++++.+',
'++.++.++++.++.++',
'+++..++++++..+++');

my ($icon, $mask) = Gtk2::Gdk::Pixmap->colormap_create_from_xpm_d
					(undef, Gtk2::Gdk::Colormap->get_system,
					 undef, @eyes_xpm);

$pixmap = Gtk2::Pixmap->new ($icon, $mask);
isa_ok ($pixmap, 'Gtk2::Pixmap');

$pixmap->set ($icon, $mask);
my ($p, $m) = $pixmap->get;
isa_ok ($p, 'Gtk2::Gdk::Pixmap');
isa_ok ($m, 'Gtk2::Gdk::Bitmap');

# should also work fine without the mask
$pixmap->set ($icon, undef);
($p, $m) = $pixmap->get;
isa_ok ($p, 'Gtk2::Gdk::Pixmap');
is ($m, undef);

$pixmap->set_build_insensitive (TRUE);

__END__
# 
# Copyright (C) 2003 by the gtk2-perl team (see the file AUTHORS)
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA.
#


