use Gtk2::TestHelper tests => 1;
use Gtk2::Deprecated;

$clist = Gtk2::CList->new (3);
isa_ok ($clist, 'Gtk2::CList');

__END__

# accessors for struct members and such.
# some of these are directly from Gtk-Perl.

$clist->focus_row;
$clist->set_focus_row (int row);

GtkSortType sort_type (GtkCList * clist)
int sort_column (GtkCList * clist)
GdkWindow * clist_window (GtkCList * clist)
int rows(GtkCList* clist)
int columns(GtkCList*clist)
GtkSelectionMode selection_mode (GtkCList*clist)

@list = $clist->selection;

@rows = $clist->row_list;


## regular api functions

GtkWidget * gtk_clist_new (SV * class, gint columns)
GtkWidget * gtk_clist_new_with_titles (SV * class, gchar * title, ...)

void gtk_clist_set_hadjustment (GtkCList *clist, GtkAdjustment *adjustment);

void gtk_clist_set_vadjustment (GtkCList *clist, GtkAdjustment *adjustment);

GtkAdjustment* gtk_clist_get_hadjustment (GtkCList *clist);

GtkAdjustment* gtk_clist_get_vadjustment (GtkCList *clist);

void gtk_clist_set_shadow_type (GtkCList *clist, GtkShadowType type);

void gtk_clist_set_selection_mode (GtkCList *clist, GtkSelectionMode mode);

void gtk_clist_set_reorderable (GtkCList *clist, gboolean reorderable);

void gtk_clist_set_use_drag_icons (GtkCList *clist, gboolean use_icons);

void gtk_clist_set_button_actions (GtkCList *clist, guint button, GtkButtonAction button_actions);

void gtk_clist_freeze (GtkCList *clist);

void gtk_clist_thaw   (GtkCList *clist);

void gtk_clist_column_titles_show (GtkCList *clist);

void gtk_clist_column_titles_hide (GtkCList *clist);

void gtk_clist_column_title_active   (GtkCList *clist, gint      column);

void gtk_clist_column_title_passive  (GtkCList *clist, gint      column);

void gtk_clist_column_titles_active  (GtkCList *clist);

void gtk_clist_column_titles_passive (GtkCList *clist);

void gtk_clist_set_column_title (GtkCList *clist, gint column, const gchar *title);

gchar * gtk_clist_get_column_title (GtkCList *clist, gint column);

void gtk_clist_set_column_widget (GtkCList  *clist, gint column, GtkWidget *widget);

GtkWidget * gtk_clist_get_column_widget (GtkCList *clist, gint column);

void gtk_clist_set_column_justification (GtkCList *clist, gint column, GtkJustification  justification);

void gtk_clist_set_column_visibility (GtkCList *clist, gint column, gboolean  visible);

void gtk_clist_set_column_resizeable (GtkCList *clist, gint column, gboolean  resizeable);

void gtk_clist_set_column_auto_resize (GtkCList *clist, gint column, gboolean auto_resize);

gint gtk_clist_columns_autosize (GtkCList *clist);

gint gtk_clist_optimal_column_width (GtkCList *clist, gint column);

void gtk_clist_set_column_width (GtkCList *clist, gint column, gint width);

void gtk_clist_set_column_min_width (GtkCList *clist, gint column, gint min_width);

void gtk_clist_set_column_max_width (GtkCList *clist, gint column, gint max_width);

void gtk_clist_set_row_height (GtkCList *clist, guint height);

void gtk_clist_moveto (GtkCList *clist, gint row, gint column, gfloat row_align, gfloat col_align);

GtkVisibility gtk_clist_row_is_visible (GtkCList *clist, gint row);

GtkCellType gtk_clist_get_cell_type (GtkCList *clist, gint row, gint column);

void gtk_clist_set_text (GtkCList *clist, gint row, gint column, const gchar *text);

gchar * gtk_clist_get_text (GtkCList  *clist, gint row, gint column)

void gtk_clist_set_pixmap (GtkCList  *clist, gint row, gint column, GdkPixmap *pixmap, GdkBitmap_ornull *mask);

void
gtk_clist_get_pixmap (GtkCList *clist, gint row, gint column)
    PREINIT:
	GdkPixmap *pixmap;
	GdkBitmap *mask;
    PPCODE:
	if (gtk_clist_get_pixmap (clist, row, column, &pixmap, (GIMME == G_ARRAY) ?&mask: NULL)) {
		XPUSHs (sv_2mortal (newSVGdkPixmap (pixmap)));
		if (mask)
			XPUSHs (sv_2mortal (newSVGdkBitmap (mask)));
	}

void gtk_clist_set_pixtext (GtkCList *clist, gint row, gint column, const gchar *text, guint8 spacing, GdkPixmap *pixmap, GdkBitmap_ornull *mask);

void
gtk_clist_get_pixtext (GtkCList *clist, gint row, gint column)
    PREINIT:
	gchar *text = NULL;
	guint8 spacing;
	GdkPixmap *pixmap = NULL;
	GdkBitmap *mask = NULL;
    PPCODE:
	if (gtk_clist_get_pixtext(clist, row, column, &text, &spacing, &pixmap, &mask)) {
		EXTEND (sp, 4);
		if (text)
			PUSHs (sv_2mortal (newSVpv (text, 0)));
		else
			PUSHs (sv_2mortal (newSVsv (&PL_sv_undef)));
		PUSHs (sv_2mortal (newSViv (spacing)));
		if (pixmap)
			PUSHs (sv_2mortal (newSVGdkPixmap (pixmap)));
		else
			PUSHs (sv_2mortal (newSVsv (&PL_sv_undef)));
		if (mask)
			PUSHs (sv_2mortal (newSVGdkBitmap (mask)));
		else
			PUSHs (sv_2mortal (newSVsv (&PL_sv_undef)));
	}

void gtk_clist_set_foreground (GtkCList *clist, gint row, GdkColor *color);

void gtk_clist_set_background (GtkCList *clist, gint row, GdkColor *color);

void gtk_clist_set_cell_style (GtkCList *clist, gint row, gint column, GtkStyle *style);

GtkStyle *gtk_clist_get_cell_style (GtkCList *clist, gint row, gint column);

void gtk_clist_set_row_style (GtkCList *clist, gint row, GtkStyle *style);

GtkStyle *gtk_clist_get_row_style (GtkCList *clist, gint row);

void gtk_clist_set_shift (GtkCList *clist, gint row, gint column, gint vertical, gint horizontal);

void gtk_clist_set_selectable (GtkCList *clist, gint row, gboolean selectable);

gboolean gtk_clist_get_selectable (GtkCList *clist, gint row);

gint gtk_clist_prepend (GtkCList *clist, gchar *text, ...)

gint gtk_clist_insert (GtkCList *clist, gint row, gchar *text, ...);

void gtk_clist_remove (GtkCList *clist, gint row);

void gtk_clist_set_row_data (GtkCList *clist, gint row, SV * data)

SV * gtk_clist_get_row_data (GtkCList *clist, gint row)

gint gtk_clist_find_row_from_data (GtkCList *clist, SV * data);

void gtk_clist_select_row (GtkCList *clist, gint row, gint column);

void gtk_clist_unselect_row (GtkCList *clist, gint row, gint column);

void gtk_clist_undo_selection (GtkCList *clist);

void gtk_clist_clear (GtkCList *clist);

gint gtk_clist_get_selection_info (GtkCList *clist, gint x, gint y)
    PREINIT:
	gint row, column;
    PPCODE:
	if (gtk_clist_get_selection_info (clist, x, y, &row, &column)) {
		EXTEND (SP, 2);
		PUSHs (sv_2mortal (newSViv (row)));
		PUSHs (sv_2mortal (newSViv (column)));
	}

void gtk_clist_select_all (GtkCList *clist);

void gtk_clist_unselect_all (GtkCList *clist);

void gtk_clist_swap_rows (GtkCList *clist, gint row1, gint row2);

void gtk_clist_row_move (GtkCList *clist, gint source_row, gint dest_row);

void gtk_clist_set_compare_func (GtkCList *clist, SV * handler, SV * data)

void gtk_clist_set_sort_column (GtkCList *clist, gint column);

void gtk_clist_set_sort_type (GtkCList *clist, GtkSortType sort_type);

void gtk_clist_sort (GtkCList *clist);

void gtk_clist_set_auto_sort (GtkCList *clist, gboolean  auto_sort);

