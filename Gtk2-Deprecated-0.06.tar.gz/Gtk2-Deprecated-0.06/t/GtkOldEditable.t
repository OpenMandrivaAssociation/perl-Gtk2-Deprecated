use Gtk2::TestHelper tests => 9;
use Gtk2::Deprecated;

$oldeditable = Gtk2::Text->new;
isa_ok ($oldeditable, 'Gtk2::OldEditable');

my $text = "this is a test of the egermancy broadcast system.  if this had been actual egermancy, everyone to go from street.";
$oldeditable->insert (undef, undef, undef, $text);
is ($oldeditable->get_chars(), $text);
is ($oldeditable->get_chars(0, 4), "this");
is ($oldeditable->get_chars(106, -1), "street.");


is ($oldeditable->current_pos, 0);
is ($oldeditable->selection_start_pos, 0);
is ($oldeditable->selection_end_pos, 0);
ok (!$oldeditable->has_selection);

$oldeditable->signal_connect (changed => sub { ok (1); });
$oldeditable->changed;

my $win = Gtk2::Window->new;
$win->add ($oldeditable);
$oldeditable->realize;
$oldeditable->claim_selection (TRUE, Gtk2->get_current_event_time);

#
# Copyright (C) 2003 by the gtk2-perl team (see the file AUTHORS)
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA.
#
