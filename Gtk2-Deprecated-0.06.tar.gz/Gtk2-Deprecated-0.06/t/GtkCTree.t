use Gtk2::TestHelper tests => 1;
use Gtk2::Deprecated;

$ctree = Gtk2::CTree->new (3, 0);
isa_ok ($ctree, 'Gtk2::CTree');

__END__
/* 
 * Copyright (C) 2003 by the gtk2-perl team (see the file AUTHORS)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#include "gtk2perl_deprecated.h"


static GPerlCallback *
make_ctree_func (SV * func, SV * data)
{
	GType param_types[] = { GTK_TYPE_CTREE_NODE };
	return gperl_callback_new (func, data, 1, param_types, G_TYPE_NONE);
}

static void
gtk2perl_gtk_ctree_func (GtkCTree * ctree,
			 GtkCTreeNode * node,
			 GPerlCallback * callback)
{
	gperl_callback_invoke (callback, NULL, ctree, node);
}

gpointer 
gtk2perl_ctree_row_copy (gpointer boxed)
{
	GtkCTreeRow * row = NULL;
	if (boxed) {
		row = g_new (GtkCTreeRow, 1);
		memcpy (row, boxed, sizeof (GtkCTreeRow));
	}
	return row;
}

GType
gtk2perl_ctree_row_get_type (void)
{
	static t = 0;
	if (!t)
		t = g_boxed_type_register_static ("GtkCTreeRow",
		                                  gtk2perl_ctree_row_copy,
			                          g_free);
	return t;
}

MODULE = Gtk2::CTree	PACKAGE = Gtk2::CTree	PREFIX = gtk_ctree_

int
tree_indent(ctree)
	GtkCTree* ctree
	CODE:
	RETVAL=ctree->tree_indent;
	OUTPUT:
	RETVAL

int
tree_column(ctree)
	GtkCTree*	ctree
	CODE:
	RETVAL=ctree->tree_column;
	OUTPUT:
	RETVAL

GtkCTreeLineStyle
line_style(ctree)
	GtkCTree*	ctree
	CODE:
	RETVAL=ctree->line_style;
	OUTPUT:
	RETVAL

MODULE = Gtk2::CTree	PACKAGE = Gtk2::CTreeRow	PREFIX = gtk_ctree_row_

int
is_leaf(ctree_row)
	GtkCTreeRow*	ctree_row
	CODE:
	RETVAL=ctree_row->is_leaf;
	OUTPUT:
	RETVAL

int
expanded(ctree_row)
	GtkCTreeRow*	ctree_row
	CODE:
	RETVAL=ctree_row->expanded;
	OUTPUT:
	RETVAL

GtkCTreeNode*
children (ctree_row)
	GtkCTreeRow*	ctree_row
	CODE:
	RETVAL = ctree_row->children;
	OUTPUT:
	RETVAL

GtkCTreeNode*
sibling (ctree_row)
	GtkCTreeRow*	ctree_row
	CODE:
	RETVAL = ctree_row->sibling;
	OUTPUT:
	RETVAL

GtkCTreeNode*
parent (ctree_row)
	GtkCTreeRow*	ctree_row
	CODE:
	RETVAL = ctree_row->parent;
	OUTPUT:
	RETVAL

MODULE = Gtk2::CTree	PACKAGE = Gtk2::CTree	PREFIX = gtk_ctree_

###GtkWidget * gtk_ctree_new_with_titles (gint columns, gint tree_column, gchar *titles[]);
GtkCTree*
gtk_ctree_new_with_titles(Class, tree_column, title, ...)
	SV *	Class
	int	tree_column
	SV *	title
	CODE:
	warn_deprecated ("Gtk2::CTree is deprecated, use Gtk2::TreeStore and Gtk2::TreeView instead");
	{
		int columns = items - 2;
		int i;
		char** titles = malloc(columns * sizeof(gchar*));
		for (i=2; i < items; ++i)
			titles[i-2] = SvGChar(ST(i));
		RETVAL = (GtkCTree*)(gtk_ctree_new_with_titles(columns, tree_column, titles));
		free(titles);
	}
	OUTPUT:
	RETVAL

GtkWidget * gtk_ctree_new (SV * class, gint columns, gint tree_column);
    CODE:
	warn_deprecated ("Gtk2::CTree is deprecated, use Gtk2::TreeStore and Gtk2::TreeView instead");
	RETVAL = gtk_ctree_new (columns, tree_column);
    OUTPUT:
	RETVAL

 #ARG: $titles reference (refrence to an array of strings)
GtkCTreeNode*
gtk_ctree_insert_node(ctree, parent, sibling, titles, spacing=5, pixmap_closed=NULL, mask_closed=NULL, pixmap_opened=NULL, mask_opened=NULL, is_leaf=TRUE, expanded=FALSE)
	GtkCTree*		ctree
	GtkCTreeNode_ornull*		parent
	GtkCTreeNode_ornull*		sibling
	SV*			titles
	int			spacing
	GdkPixmap_ornull*	pixmap_closed
	GdkBitmap_ornull*	mask_closed
	GdkPixmap_ornull*	pixmap_opened
	GdkBitmap_ornull*	mask_opened
	bool			is_leaf
	bool			expanded
	ALIAS:
		Gtk::CTree::insert_node = 0
		Gtk::CTree::insert = 1
	CODE:
	{
		char** titlesa;
		AV* av;
		SV** temp;
		int i;
		if (!SvROK(titles) || (SvTYPE(SvRV(titles)) != SVt_PVAV))
			croak("titles must be a reference to an array");
		av = (AV*)SvRV(titles);
		titlesa = (char**)malloc(sizeof(char*) * (av_len(av)+2));
		for(i = 0; i <= av_len(av); ++i) {
			temp = av_fetch(av,i,0);
			titlesa[i] = temp?SvPV(*temp,PL_na):"";
		}
		titlesa[i]=0;
		RETVAL = gtk_ctree_insert_node(ctree, parent, sibling, titlesa, spacing, pixmap_closed, mask_closed, pixmap_opened, mask_opened, is_leaf, expanded);
		free(titlesa);
	}
	OUTPUT:
	RETVAL

void gtk_ctree_remove_node (GtkCTree *ctree, GtkCTreeNode *node);

##GtkCTreeNode * gtk_ctree_insert_gnode            (GtkCTree          *ctree,
##						  GtkCTreeNode      *parent,
##						  GtkCTreeNode      *sibling,
##						  GNode             *gnode,
##						  GtkCTreeGNodeFunc  func,
##						  gpointer           data);
##GNode * gtk_ctree_export_to_gnode                (GtkCTree          *ctree,
##						  GNode             *parent,
##						  GNode             *sibling,
##						  GtkCTreeNode      *node,
##						  GtkCTreeGNodeFunc  func,
##						  gpointer           data);


void gtk_ctree_post_recursive (GtkCTree *ctree, GtkCTreeNode *node, SV * func, SV * data);
    ALIAS:
	gtk_ctree_pre_recursive = 1
    PREINIT:
	GPerlCallback * callback;
    CODE:
	callback = make_ctree_func (func, data);
	if (ix == 1)
		gtk_ctree_pre_recursive (ctree, node,
					 (GtkCTreeFunc)gtk2perl_gtk_ctree_func,
					 callback);
	else
		gtk_ctree_post_recursive (ctree, node,
					  (GtkCTreeFunc)gtk2perl_gtk_ctree_func,
					  callback);
	gperl_callback_destroy (callback);



void gtk_ctree_post_recursive_to_depth (GtkCTree *ctree, GtkCTreeNode *node, int depth, SV * func, SV * data);
    ALIAS:
	gtk_ctree_pre_recursive_to_depth = 1
    PREINIT:
	GPerlCallback * callback;
    CODE:
	callback = make_ctree_func (func, data);
	if (ix == 1)
		gtk_ctree_pre_recursive_to_depth (ctree, node, depth,
					 (GtkCTreeFunc)gtk2perl_gtk_ctree_func,
					 callback);
	else
		gtk_ctree_post_recursive_to_dpth (ctree, node, depth,
					  (GtkCTreeFunc)gtk2perl_gtk_ctree_func,
					  callback);
	gperl_callback_destroy (callback);


gboolean gtk_ctree_is_viewable (GtkCTree *ctree, GtkCTreeNode *node);

GtkCTreeNode * gtk_ctree_last (GtkCTree *ctree, GtkCTreeNode *node);

GtkCTreeNode * gtk_ctree_find_node_ptr (GtkCTree *ctree, GtkCTreeRow *ctree_row);

GtkCTreeNode * gtk_ctree_node_nth (GtkCTree *ctree, guint row);

gboolean gtk_ctree_find (GtkCTree *ctree, GtkCTreeNode *node, GtkCTreeNode *child);

gboolean gtk_ctree_is_ancestor (GtkCTree *ctree, GtkCTreeNode *node, GtkCTreeNode *child);

##GtkCTreeNode * gtk_ctree_find_by_row_data        (GtkCTree     *ctree,
##					          GtkCTreeNode *node,
##					          gpointer      data);
##/* returns a GList of all GtkCTreeNodes with row->data == data. */
##GList * gtk_ctree_find_all_by_row_data           (GtkCTree     *ctree,
##						  GtkCTreeNode *node,
##						  gpointer      data);
##GtkCTreeNode * gtk_ctree_find_by_row_data_custom (GtkCTree     *ctree,
##						  GtkCTreeNode *node,
##						  gpointer      data,
##						  GCompareFunc  func);
##/* returns a GList of all GtkCTreeNodes with row->data == data. */
##GList * gtk_ctree_find_all_by_row_data_custom    (GtkCTree     *ctree,
##						  GtkCTreeNode *node,
##						  gpointer      data,
##						  GCompareFunc  func);

gboolean gtk_ctree_is_hot_spot (GtkCTree *ctree, gint x, gint y);

void gtk_ctree_move (GtkCTree *ctree, GtkCTreeNode *node, GtkCTreeNode *new_parent, GtkCTreeNode *new_sibling);

void gtk_ctree_expand (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_expand_recursive (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_expand_to_depth (GtkCTree *ctree, GtkCTreeNode *node, gint depth);

void gtk_ctree_collapse (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_collapse_recursive (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_collapse_to_depth (GtkCTree *ctree, GtkCTreeNode *node, gint depth);

void gtk_ctree_toggle_expansion (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_toggle_expansion_recursive (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_select (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_select_recursive (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_unselect (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_unselect_recursive (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_real_select_recursive (GtkCTree *ctree, GtkCTreeNode *node, gint state);


void gtk_ctree_node_set_text (GtkCTree *ctree, GtkCTreeNode *node, gint column, const gchar  *text);

void gtk_ctree_node_set_pixmap (GtkCTree *ctree, GtkCTreeNode *node, gint column, GdkPixmap *pixmap, GdkBitmap_ornull *mask);

void gtk_ctree_node_set_pixtext (GtkCTree *ctree, GtkCTreeNode *node, gint column, const gchar  *text, guint8 spacing, GdkPixmap *pixmap, GdkBitmap_ornull *mask);

void gtk_ctree_set_node_info (GtkCTree *ctree, GtkCTreeNode *node, const gchar *text, guint8 spacing, GdkPixmap *pixmap_closed, GdkBitmap_ornull *mask_closed, GdkPixmap *pixmap_opened, GdkBitmap_ornull *mask_opened, gboolean is_leaf, gboolean expanded);

void gtk_ctree_node_set_shift (GtkCTree *ctree, GtkCTreeNode *node, gint column, gint vertical, gint horizontal);

void gtk_ctree_node_set_selectable (GtkCTree *ctree, GtkCTreeNode *node, gboolean selectable);

gboolean gtk_ctree_node_get_selectable (GtkCTree *ctree, GtkCTreeNode *node);

GtkCellType gtk_ctree_node_get_cell_type (GtkCTree *ctree, GtkCTreeNode *node, gint column);

gchar *
gtk_ctree_node_get_text (GtkCTree *ctree, GtkCTreeNode *node, gint column)
     CODE:
	if (!gtk_ctree_node_get_text (ctree, node, column, &RETVAL))
		XSRETURN_UNDEF;
    OUTPUT:
	RETVAL

### gboolean gtk_ctree_node_get_pixmap (GtkCTree *ctree, GtkCTreeNode *node, gint column, GdkPixmap **pixmap, GdkBitmap **mask);
void
gtk_ctree_node_get_pixmap (ctree, node, column)
	GtkCTree	* ctree
	GtkCTreeNode	* node
	int column
	ALIAS:
		Gtk::CTree::node_get_pixmap = 0
		Gtk::CTree::get_pixmap = 1
	PPCODE:
	{
		GdkPixmap * pixmap = NULL;
		GdkBitmap * bitmap = NULL;
		int result;
		result = gtk_ctree_node_get_pixmap(ctree, node, column, &pixmap, (GIMME == G_ARRAY) ?&bitmap: NULL);
		if ( result ) {
			if ( pixmap ) {
				EXTEND(sp, 1);
				PUSHs(sv_2mortal(newSVGdkPixmap(pixmap)));
			}
			if (bitmap ) {
				EXTEND(sp, 1);
				PUSHs(sv_2mortal(newSVGdkBitmap(bitmap)));
			}
		}
	}

### gboolean gtk_ctree_node_get_pixtext (GtkCTree *ctree, GtkCTreeNode *node, gint column, gchar **text, guint8 *spacing, GdkPixmap **pixmap, GdkBitmap **mask);
void
gtk_ctree_node_get_pixtext (ctree, node, column)
	GtkCTree*	ctree
	GtkCTreeNode*	node
	int column
	ALIAS:
		Gtk::CTree::node_get_pixtext = 0
		Gtk::CTree::get_pixtext = 1
	PPCODE:
	{
		gchar* text = NULL;
		guint8 spacing;
		GdkPixmap * pixmap = NULL;
		GdkBitmap * bitmap = NULL;
		int result;
		/* FIXME: require GIMME == G_ARRAY? */
		result = gtk_ctree_node_get_pixtext(ctree, node, column, &text, &spacing, &pixmap, &bitmap);
		if ( result ) {
			EXTEND(sp, 4);
			if ( text )
				PUSHs(sv_2mortal(newSVpv(text, 0)));
			else
				PUSHs(sv_2mortal(newSVsv(&PL_sv_undef)));
			PUSHs(sv_2mortal(newSViv(spacing)));
			if ( pixmap )
				PUSHs(sv_2mortal(newSVGdkPixmap(pixmap)));
			else
				PUSHs(sv_2mortal(newSVsv(&PL_sv_undef)));
			if (bitmap )
				PUSHs(sv_2mortal(newSVGdkBitmap(bitmap)));
			else
				PUSHs(sv_2mortal(newSVsv(&PL_sv_undef)));
		}
	}

#gboolean gtk_ctree_get_node_info                 (GtkCTree     *ctree,
#						  GtkCTreeNode *node,
#						  gchar       **text,
#						  guint8       *spacing,
#						  GdkPixmap   **pixmap_closed,
#						  GdkBitmap   **mask_closed,
#						  GdkPixmap   **pixmap_opened,
#						  GdkBitmap   **mask_opened,
#						  gboolean     *is_leaf,
#						  gboolean     *expanded);

void gtk_ctree_node_set_row_style (GtkCTree *ctree, GtkCTreeNode *node, GtkStyle *style);

GtkStyle * gtk_ctree_node_get_row_style (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_node_set_cell_style (GtkCTree *ctree, GtkCTreeNode *node, gint column, GtkStyle *style);

GtkStyle * gtk_ctree_node_get_cell_style (GtkCTree *ctree, GtkCTreeNode *node, gint column);

void gtk_ctree_node_set_foreground (GtkCTree *ctree, GtkCTreeNode *node, GdkColor *color);

void gtk_ctree_node_set_background (GtkCTree *ctree, GtkCTreeNode *node, GdkColor *color);


void
gtk_ctree_node_set_row_data(ctree, node, data)
	GtkCTree * ctree
	GtkCTreeNode * node
	SV *	data
	CODE:
	{
		SV * sv = (SV*)SvRV(data);
		
		/*\ Hearken: we are given a reference, called 'data', which refers to
		 *          some SV, called 'sv'. The RV is ephemeral, and we must
		 *          not form a permanent reference to it. Instead, we
		 *          increment the refcount of the target sv, and store that
		 *          sv's pointer as the row data. When the row data is
		 *          deallocated, the sv's refcount will be decremented.
		\*/

		if (!sv)
			croak("Data must be a reference");
			
		SvREFCNT_inc(sv);
		
		gtk_ctree_node_set_row_data_full(ctree, node, sv, (GtkDestroyNotify)gperl_sv_free);
	}

 #RETURNS: the reference set with Gtk::CTree:set_row_data
SV*
gtk_ctree_node_get_row_data(ctree, node)
	GtkCTree  *ctree
	GtkCTreeNode *node;
	CODE:
	{
		SV * sv = (SV*)gtk_ctree_node_get_row_data(ctree, node);
		RETVAL = sv ? newRV_inc(sv) : newSVsv(&PL_sv_undef);
	}
	OUTPUT:
	RETVAL

void gtk_ctree_node_moveto (GtkCTree *ctree, GtkCTreeNode *node, gint column, gfloat row_align, gfloat col_align);

GtkVisibility gtk_ctree_node_is_visible (GtkCTree *ctree, GtkCTreeNode *node);


void gtk_ctree_set_indent (GtkCTree *ctree, gint indent);

void gtk_ctree_set_spacing (GtkCTree *ctree, gint spacing);

void gtk_ctree_set_show_stub (GtkCTree *ctree, gboolean show_stub);

void gtk_ctree_set_line_style (GtkCTree *ctree, GtkCTreeLineStyle line_style);

void gtk_ctree_set_expander_style (GtkCTree *ctree, GtkCTreeExpanderStyle expander_style);

###void gtk_ctree_set_drag_compare_func (GtkCTree *ctree, GtkCTreeCompareDragFunc  cmp_func);


void gtk_ctree_sort_node (GtkCTree *ctree, GtkCTreeNode *node);

void gtk_ctree_sort_recursive (GtkCTree *ctree, GtkCTreeNode *node);


void gtk_ctree_set_reorderable (GtkCTree * ctree, gboolean reorderable)
    CODE:
	gtk_clist_set_reorderable (GTK_CLIST(ctree), reorderable);


MODULE = Gtk2::CTree	PACKAGE = Gtk2::CTreeNode	PREFIX = gtk_ctree_node_

 #OUTPUT: Gtk::CTreeRow
void
row(GtkCTreeNode* ctree_node)
    PPCODE:
	if (ctree_node) {
		EXTEND(sp, 1);
		PUSHs(sv_2mortal(newSVGtkCTreeRow(GTK_CTREE_ROW(ctree_node))));
	}

 #OUTPUT: Gtk::CTreeNode
void
next(GtkCTreeNode * ctree_node)
    PPCODE:
	if (ctree_node) {
		EXTEND(sp, 1);
		PUSHs(sv_2mortal(newSVGtkCTreeNode(GTK_CTREE_NODE_NEXT(ctree_node))));
	}

 #OUTPUT: Gtk::CTreeNode
void
prev(GtkCTreeNode*ctree_node)
    PPCODE:
	if (ctree_node) {
		EXTEND(sp, 1);
		PUSHs(sv_2mortal(newSVGtkCTreeNode(GTK_CTREE_NODE_PREV(ctree_node))));
	}

