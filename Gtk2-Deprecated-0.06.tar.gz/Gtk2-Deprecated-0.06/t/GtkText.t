use Gtk2::TestHelper tests => 7;
use Gtk2::Deprecated;

$text = Gtk2::Text->new;
isa_ok ($text, Gtk2::Text::);

isa_ok ($text->hadj, Gtk2::Adjustment::);
isa_ok ($text->vadj, Gtk2::Adjustment::);

$text->freeze;
$text->thaw;

# are there accessors for these?
$text->set_editable (TRUE);
$text->set_word_wrap (TRUE);
$text->set_line_wrap (TRUE);

#$text->set_adjustments (GtkAdjustment *hadj, GtkAdjustment *vadj);


###$text->insert (GdkFont_ornull *font, GdkColor_ornull *fore, GdkColor_ornull *back, const gchar_length *chars);

$text->insert (undef, undef, undef, "some chars");
$text->insert (undef,
               Gtk2::Gdk::Color->new (65535, 0, 32787),
	       Gtk2::Gdk::Color->new (0, 32787, 65535),
	       "some chars");
# font stuff isn't bound, so i can't test that.  :-/

$text->set_point (5);
is ($text->get_point, 5);

is ($text->get_length, 20);

ok ($text->backward_delete (4));
ok ($text->forward_delete (3));

##define GTK_TEXT_INDEX(t, index)	(((t)->use_wchar) \
#	? ((index) < (t)->gap_position ? (t)->text.wc[index] : \
#					(t)->text.wc[(index)+(t)->gap_size]) \
#	: ((index) < (t)->gap_position ? (t)->text.ch[index] : \
#					(t)->text.ch[(index)+(t)->gap_size]))

# 
# Copyright (C) 2003 by the gtk2-perl team (see the file AUTHORS)
#
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA.
#
