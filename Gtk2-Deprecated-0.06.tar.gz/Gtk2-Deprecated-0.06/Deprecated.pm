#
# $Header: /home/scott/lib/cvsroot/Gtk2-Deprecated/Deprecated.pm,v 1.6 2004/10/01 02:57:19 scott Exp $
#

package Gtk2::Deprecated;

use 5.008;
use strict;
use warnings;

use Gtk2;

require Exporter;
require DynaLoader;

our @ISA = qw(Exporter DynaLoader);

our $VERSION = '0.06';

sub dl_load_flags { $^O eq 'darwin' ? 0x00 : 0x01 }

bootstrap Gtk2::Deprecated $VERSION;

# Preloaded methods go here.

1;
__END__

=head1 NAME

Gtk2::Deprecated - Deprecated widgets to ease porting to Gtk2-Perl

=head1 SYNOPSIS

  use Gtk2::Deprecated;
  $clist = Gtk2::CList->new ();
  $ctree = Gtk2::CTree->new ();

=head1 ABSTRACT

  Several widgets were deprecated between Gtk+ 1.x and 2.x, and 
  deprecated widgets are intentionally omitted from the Gtk2 module.
  This module provides those deprecated widgets to ease porting.

=head1 DESCRIPTION

You should only use this module to ease porting --- don't expect these
to stick around forever, as they are deprecated.  Also don't expect it
to work too incredibly well, as we're not incredibly interested in
maintaining doomed code.  There are no examples and the docs are quite
lacking; that's somewhat intentional. ;-)

To discuss gtk2-perl, ask questions and flame/praise the authors,
join gtk-perl-list@gnome.org at lists.gnome.org.

=head1 SEE ALSO

perl(1), Glib(3pm), Gtk2(3pm).

Gtk2::Deprecated::index(3pm) lists the generated API reference for this module.

=head1 AUTHOR

muppet E<lt>scott at asofyet dot orgE<gt>

=head1 COPYRIGHT AND LICENSE

Copyright (C) 2003-2004 by muppet.  Includes code from Gtk-Perl,
Copyright (C) 1997-2001, Kenneth Albanowski, Paolo Molaro.
			
This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the 
Free Software Foundation, Inc., 59 Temple Place - Suite 330, 
Boston, MA  02111-1307  USA.

=cut
