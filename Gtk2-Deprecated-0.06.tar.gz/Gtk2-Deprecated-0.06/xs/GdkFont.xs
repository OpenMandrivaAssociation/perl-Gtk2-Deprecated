#include "gtk2perl_deprecated.h"

MODULE = Gtk2::Gdk::Font	PACKAGE = Gtk2::Gdk::Font	PREFIX = gdk_font_

GdkFontType
type (GdkFont * font)
    CODE:
	RETVAL = font->type;
    OUTPUT:
	RETVAL

int
ascent (GdkFont * font)
    CODE:
	RETVAL = font->ascent;
    OUTPUT:
	RETVAL

int
descent (GdkFont * font)
    CODE:
	RETVAL = font->descent;
    OUTPUT:
	RETVAL


 ##GdkFont* gdk_font_load (const gchar *font_name);
GdkFont* gdk_font_load (class, const gchar *font_name);
    C_ARGS:
	font_name

 ##GdkFont* gdk_fontset_load (const gchar *fontset_name);
GdkFont* gdk_fontset_load (class, const gchar *fontset_name);
    C_ARGS:
	fontset_name

 ##GdkFont* gdk_font_from_description (PangoFontDescription *font_desc);
GdkFont* gdk_font_from_description (class, PangoFontDescription *font_desc);
    C_ARGS:
	font_desc

  ## these are used by the boxed wrapper, so we don't need them.
 ## GdkFont* gdk_font_ref (GdkFont *font);
 ## void gdk_font_unref (GdkFont *font);

gint gdk_font_id (const GdkFont *font);

gboolean gdk_font_equal	(const GdkFont *fonta, const GdkFont *fontb);

MODULE = Gtk2::Gdk::Font	PACKAGE = Gtk2::Gdk::Font	PREFIX = gdk_

gint gdk_string_width (GdkFont *font, const gchar *string);

 ##gint gdk_text_width (GdkFont *font, const gchar *text, gint text_length);
gint gdk_text_width (GdkFont *font, const gchar_length *text, gint length(text));

##gint gdk_text_width_wc (GdkFont *font, const GdkWChar *text, gint text_length);

gint gdk_char_width (GdkFont *font, gchar character);

##gint gdk_char_width_wc (GdkFont *font, GdkWChar character);

gint gdk_string_measure (GdkFont *font, const gchar *string);

gint gdk_text_measure (GdkFont *font, const gchar_length *text, gint length(text));

gint gdk_char_measure (GdkFont *font, gchar character);

gint gdk_string_height (GdkFont *font, const gchar *string);

gint gdk_text_height (GdkFont *font, const gchar_length *text, gint length(text));

gint gdk_char_height (GdkFont *font, gchar character);


 ##void gdk_text_extents (GdkFont *font, const gchar *text, gint text_length,
 ##  gint *lbearing, gint *rbearing, gint *width, gint *ascent, gint *descent);

void gdk_text_extents (GdkFont *font, const gchar_length *text, gint length(text), \
    OUTLIST gint lbearing, OUTLIST gint rbearing, \
    OUTLIST gint width, OUTLIST gint ascent, OUTLIST gint descent);

##void gdk_text_extents_wc (GdkFont *font, const GdkWChar *text, gint text_length,
## gint *lbearing, gint *rbearing, gint *width, gint *ascent, gint *descent);

 ## void gdk_string_extents (GdkFont *font, const gchar *string,
 ## gint *lbearing, gint *rbearing, gint *width, gint *ascent, gint *descent);

void gdk_string_extents (GdkFont *font, const gchar *string, \
 OUTLIST gint lbearing, OUTLIST gint rbearing, OUTLIST gint width, \
 OUTLIST gint ascent, OUTLIST gint descent);

##ifdef GDK_WINDOWING_WIN32
#/* Ditto temporary */
#gchar* gdk_font_full_name_get (GdkFont *font);
#void gdk_font_full_name_free (gchar *name);
##endif

MODULE = Gtk2::Gdk::Font	PACKAGE = Gtk2::Style

=for object Gtk2::Gdk::Font
=cut

=for apidoc
The font member of Gtk2::Style is deprecated; in fact, the actual member is
gone, replaced by ->get_font(), but this API is used in many Gtk-Perl programs.
=cut
GdkFont * font (GtkStyle * style)
    CODE:
	RETVAL = gtk_style_get_font (style);
    OUTPUT:
	RETVAL

