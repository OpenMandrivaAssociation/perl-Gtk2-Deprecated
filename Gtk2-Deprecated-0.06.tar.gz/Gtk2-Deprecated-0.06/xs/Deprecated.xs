#include "gtk2perl_deprecated.h"

MODULE = Gtk2::Deprecated	PACKAGE = Gtk2::Deprecated

BOOT:
	{
#include "register.xsh"
#include "boot.xsh"
	}

