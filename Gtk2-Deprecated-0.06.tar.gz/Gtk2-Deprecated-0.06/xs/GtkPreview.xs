#include "gtk2perl_deprecated.h"

MODULE = Gtk2::Preview		PACKAGE = Gtk2::Preview		PREFIX = gtk_preview_

GtkWidget*
gtk_preview_new(Class, GtkPreviewType type)
    C_ARGS:
	type

void
gtk_preview_size(preview, width, height)
	GtkPreview*	preview
	int	width
	int	height

void
gtk_preview_put(preview, window, gc, srcx, srcy, destx, desty, width, height)
	GtkPreview*	preview
	GdkWindow*	window
	GdkGC*	gc
	int	srcx
	int	srcy
	int	destx
	int	desty
	int	width
	int	height

void
gtk_preview_draw_row(preview, data, x, y, w)
	GtkPreview*	preview
	char *	data
	int	x
	int	y
	int	w

void
gtk_preview_set_expand(preview, expand)
	GtkPreview*	preview
	gboolean	expand

void
gtk_preview_set_gamma(Class, double gamma)
    C_ARGS:
	gamma

void
gtk_preview_set_color_cube (class, nred_shades, ngreen_shades, nblue_shades, ngray_shades)
	int	nred_shades
	int	ngreen_shades
	int	nblue_shades
	int	ngray_shades
    C_ARGS:
	nred_shades, ngreen_shades, nblue_shades, ngray_shades

void
gtk_preview_set_install_cmap(Class, int install_cmap)
    C_ARGS:
    	install_cmap

void
gtk_preview_set_reserved(Class, int reserved)
    C_ARGS:
	reserved

GdkVisual*
gtk_preview_get_visual(Class)
    C_ARGS:
	/*void*/

GdkColormap*
gtk_preview_get_cmap(Class)
    C_ARGS:
	/*void*/

# FIXME: Add gtk_preview_get_info
 ## NOTE: sic.  as of Gtk-Perl-0.7009, it was never bound, so there's no
 ## sense in binding it now.

