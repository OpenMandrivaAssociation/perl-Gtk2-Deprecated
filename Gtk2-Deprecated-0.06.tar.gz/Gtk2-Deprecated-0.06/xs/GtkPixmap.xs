/* 
 * Copyright (C) 2003 by the gtk2-perl team (see the file AUTHORS)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#include "gtk2perl_deprecated.h"
#ifndef newSVGdkBitmap_ornull
# define newSVGdkBitmap_ornull(b) (b ? newSVGdkBitmap (b) : Nullsv)
#endif

MODULE = Gtk2::Pixmap	PACKAGE = Gtk2::Pixmap	PREFIX = gtk_pixmap_

GtkWidget* gtk_pixmap_new (class, GdkPixmap *pixmap, GdkBitmap_ornull *mask);
    C_ARGS:
	pixmap, mask
    CLEANUP:
	warn_deprecated ("Gtk2::Pixmap is deprecated, use Gtk2::Image instead");

void gtk_pixmap_set (GtkPixmap *pixmap, GdkPixmap *val, GdkBitmap_ornull *mask);

void gtk_pixmap_get (GtkPixmap *pixmap, OUTLIST GdkPixmap *val, OUTLIST GdkBitmap_ornull *mask);

void gtk_pixmap_set_build_insensitive (GtkPixmap *pixmap, gboolean build);

