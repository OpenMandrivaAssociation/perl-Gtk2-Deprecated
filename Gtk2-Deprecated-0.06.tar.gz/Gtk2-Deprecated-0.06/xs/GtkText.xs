/* 
 * Copyright (C) 2003 by the gtk2-perl team (see the file AUTHORS)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#include "gtk2perl_deprecated.h"



MODULE = Gtk2::Text	PACKAGE = Gtk2::Text	PREFIX = gtk_text_

GtkAdjustment_ornull*
hadj(text)
	GtkText*	text
    CODE:
	RETVAL = text->hadj;
    OUTPUT:
	RETVAL

GtkAdjustment_ornull*
vadj(text)
	GtkText*	text
    CODE:
	RETVAL = text->vadj;
    OUTPUT:
	RETVAL

GtkWidget* gtk_text_new (class, GtkAdjustment_ornull *hadj=NULL, GtkAdjustment_ornull *vadj=NULL)
    C_ARGS:
	hadj, vadj
    CLEANUP:
	warn_deprecated ("Gtk2::Text is deprecated, use Gtk2::TextBuffer and Gtk2::TextView instead");

void gtk_text_set_editable (GtkText *text, gboolean editable);

void gtk_text_set_word_wrap (GtkText *text, gboolean word_wrap);

void gtk_text_set_line_wrap (GtkText *text, gboolean line_wrap);

void gtk_text_set_adjustments (GtkText *text, GtkAdjustment *hadj, GtkAdjustment *vadj);

void gtk_text_set_point (GtkText *text, guint index);

guint gtk_text_get_point (GtkText *text);

guint gtk_text_get_length (GtkText *text);

void gtk_text_freeze (GtkText *text);

void gtk_text_thaw (GtkText *text);

void gtk_text_insert (GtkText *text, GdkFont_ornull *font, GdkColor_ornull *fore, GdkColor_ornull *back, const gchar_length *chars, int length(chars));

gboolean gtk_text_backward_delete (GtkText *text, guint nchars);

gboolean gtk_text_forward_delete (GtkText *text, guint nchars);

#define GTK_TEXT_INDEX(t, index)	(((t)->use_wchar) \
	? ((index) < (t)->gap_position ? (t)->text.wc[index] : \
					(t)->text.wc[(index)+(t)->gap_size]) \
	: ((index) < (t)->gap_position ? (t)->text.ch[index] : \
					(t)->text.ch[(index)+(t)->gap_size]))
