/* 
 * Copyright (C) 2003 by the gtk2-perl team (see the file AUTHORS)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/*
 * Modified by the GTK+ Team and others 1997-2000.  See the AUTHORS
 * file for a list of people on the GTK+ Team.  See the ChangeLog
 * files for a list of changes.  These files are distributed with
 * GTK+ at ftp://ftp.gtk.org/pub/gtk/. 
 */

#include "gtk2perl_deprecated.h"

MODULE = Gtk2::OldEditable	PACKAGE = Gtk2::OldEditable	PREFIX = gtk_old_editable_

guint
current_pos (editable)
	GtkOldEditable* editable
	ALIAS:
		Gtk2::OldEditable::selection_start_pos = 1
		Gtk2::OldEditable::selection_end_pos = 2
		Gtk2::OldEditable::has_selection = 3
	CODE:
	switch (ix) {
	case 0: RETVAL = editable->current_pos; break;
	case 1: RETVAL = editable->selection_start_pos; break;
	case 2: RETVAL = editable->selection_end_pos; break;
	case 3: RETVAL = editable->has_selection; break;
	default: RETVAL = 0; g_assert_not_reached ();
	}
	OUTPUT:
	RETVAL


void gtk_old_editable_claim_selection (GtkOldEditable *old_editable, gboolean claim, guint32 time);

void gtk_old_editable_changed (GtkOldEditable *old_editable);

=for apidoc
Retrieves a sequence of characters.  The characters that are retrieved are those
characters at positions from I<start_pos> up to, but not including I<end_pos>.
If I<end_pos> is negative, then the the characters retrieved will be those
characters from I<start_pos> to the end of the text.
=cut
gchar_own * get_chars (GtkOldEditable *old_editable, gint start_pos=0, gint end_pos=-1)
    CODE:
	{
	GtkOldEditableClass *klass = GTK_OLD_EDITABLE_GET_CLASS (old_editable);
	RETVAL = klass->get_chars (GTK_OLD_EDITABLE (old_editable), start_pos, end_pos);
	}
    OUTPUT:
	RETVAL
