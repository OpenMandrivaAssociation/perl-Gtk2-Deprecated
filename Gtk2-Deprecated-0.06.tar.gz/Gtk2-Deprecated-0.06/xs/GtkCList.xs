/* 
 * Copyright (C) 2003 by the gtk2-perl team (see the file AUTHORS)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#include "gtk2perl_deprecated.h"

#if 0
/* clist flags */
enum {
  GTK_CLIST_IN_DRAG             = 1 <<  0,
  GTK_CLIST_ROW_HEIGHT_SET      = 1 <<  1,
  GTK_CLIST_SHOW_TITLES         = 1 <<  2,
  /* Unused */
  GTK_CLIST_ADD_MODE            = 1 <<  4,
  GTK_CLIST_AUTO_SORT           = 1 <<  5,
  GTK_CLIST_AUTO_RESIZE_BLOCKED = 1 <<  6,
  GTK_CLIST_REORDERABLE         = 1 <<  7,
  GTK_CLIST_USE_DRAG_ICONS      = 1 <<  8,
  GTK_CLIST_DRAW_DRAG_LINE      = 1 <<  9,
  GTK_CLIST_DRAW_DRAG_RECT      = 1 << 10
}; 
#endif

#if 0

#define GTK_CLIST_GET_CLASS(obj)  (GTK_CHECK_GET_CLASS ((obj), GTK_TYPE_CLIST, GtkCListClass))


#define GTK_CLIST_FLAGS(clist)             (GTK_CLIST (clist)->flags)
#define GTK_CLIST_SET_FLAG(clist,flag)     (GTK_CLIST_FLAGS (clist) |= (GTK_ ## flag))
#define GTK_CLIST_UNSET_FLAG(clist,flag)   (GTK_CLIST_FLAGS (clist) &= ~(GTK_ ## flag))

#define GTK_CLIST_IN_DRAG(clist)           (GTK_CLIST_FLAGS (clist) & GTK_CLIST_IN_DRAG)
#define GTK_CLIST_ROW_HEIGHT_SET(clist)    (GTK_CLIST_FLAGS (clist) & GTK_CLIST_ROW_HEIGHT_SET)
#define GTK_CLIST_SHOW_TITLES(clist)       (GTK_CLIST_FLAGS (clist) & GTK_CLIST_SHOW_TITLES)
#define GTK_CLIST_ADD_MODE(clist)          (GTK_CLIST_FLAGS (clist) & GTK_CLIST_ADD_MODE)
#define GTK_CLIST_AUTO_SORT(clist)         (GTK_CLIST_FLAGS (clist) & GTK_CLIST_AUTO_SORT)
#define GTK_CLIST_AUTO_RESIZE_BLOCKED(clist) (GTK_CLIST_FLAGS (clist) & GTK_CLIST_AUTO_RESIZE_BLOCKED)
#define GTK_CLIST_REORDERABLE(clist)       (GTK_CLIST_FLAGS (clist) & GTK_CLIST_REORDERABLE)
#define GTK_CLIST_USE_DRAG_ICONS(clist)    (GTK_CLIST_FLAGS (clist) & GTK_CLIST_USE_DRAG_ICONS)
#define GTK_CLIST_DRAW_DRAG_LINE(clist)    (GTK_CLIST_FLAGS (clist) & GTK_CLIST_DRAW_DRAG_LINE)
#define GTK_CLIST_DRAW_DRAG_RECT(clist)    (GTK_CLIST_FLAGS (clist) & GTK_CLIST_DRAW_DRAG_RECT)

#define GTK_CLIST_ROW(_glist_) ((GtkCListRow *)((_glist_)->data))

/* pointer casting for cells */
#define GTK_CELL_TEXT(cell)     (((GtkCellText *) &(cell)))
#define GTK_CELL_PIXMAP(cell)   (((GtkCellPixmap *) &(cell)))
#define GTK_CELL_PIXTEXT(cell)  (((GtkCellPixText *) &(cell)))
#define GTK_CELL_WIDGET(cell)   (((GtkCellWidget *) &(cell)))

#endif

/*
straight from the old Gtk-Perl, with hacks
*/

static int
my_clist_compare(GtkCList * clist, gconstpointer a, gconstpointer b) {
	GtkCListRow *row1 = (GtkCListRow *) a;
	GtkCListRow *row2 = (GtkCListRow *) b;
	GPerlCallback * callback;
	char * t1=NULL, *t2=NULL;
	int result, i;
	dSP;

	callback = gtk_object_get_data(GTK_OBJECT(clist), "_perl_sort_cb");

	switch (row1->cell[clist->sort_column].type) {
	case GTK_CELL_TEXT:
		t1 = GTK_CELL_TEXT (row1->cell[clist->sort_column])->text;
		break;
	case GTK_CELL_PIXTEXT:
		t1 = GTK_CELL_PIXTEXT (row1->cell[clist->sort_column])->text;
		break;
	default:
		break;
	}
	switch (row2->cell[clist->sort_column].type) {
	case GTK_CELL_TEXT:
		t2 = GTK_CELL_TEXT (row2->cell[clist->sort_column])->text;
		break;
	case GTK_CELL_PIXTEXT:
		t2 = GTK_CELL_PIXTEXT (row2->cell[clist->sort_column])->text;
		break;
	default:
		break;
	}

	ENTER;
	SAVETMPS;
	PUSHMARK(SP);
	/* we may want to push all the columns text in an array ref ... */
	XPUSHs(sv_2mortal(newSVGtkObject(GTK_OBJECT(clist))));
	XPUSHs(sv_2mortal(t1?newSVpv(t1, 0):newSVsv(&PL_sv_undef)));
	XPUSHs(sv_2mortal(t2?newSVpv(t2, 0):newSVsv(&PL_sv_undef)));
	if (callback->data)
		XPUSHs(sv_2mortal(callback->data));
	PUTBACK;
	i = call_sv(callback->func, G_SCALAR);
	if (i!=1)
		croak("handler failed");

	SPAGAIN;
	result = POPi;
	PUTBACK;
	FREETMPS;
	LEAVE;

	return result;
}

SV *
newSVGtkCListRow (GtkCListRow * row)
{
	return sv_setref_pv (newSV (0), "Gtk2::CListRow", (void*)row);
}

GtkCListRow *
SvGtkCListRow (SV * sv)
{
	if (sv && SvOK (sv) && SvROK (sv))
		return (GtkCListRow*) SvIV (SvRV (sv));
	else
		return NULL;
}

static void
row_data_destroy (gpointer data)
{
	SvREFCNT_dec ((SV*)data);
}

MODULE = Gtk2::CList	PACKAGE = Gtk2::CList	PREFIX = gtk_clist_

# accessors for struct members and such.
# some of these are directly from Gtk-Perl.

int focus_row (GtkCList * clist)
    CODE:
	RETVAL=clist->focus_row;
    OUTPUT:
	RETVAL

void set_focus_row (GtkCList * clist, int row)
    CODE:
	if (row >= 0 && row < clist->rows)
		clist->focus_row = row;
	else
		warn("incorrect row %d", row);
	if (clist->freeze_count == 0)
		gtk_widget_draw (GTK_WIDGET (clist), NULL);

GtkSortType sort_type (GtkCList * clist)
    CODE:
	RETVAL=clist->sort_type;
    OUTPUT:
	RETVAL

int sort_column (GtkCList * clist)
    CODE:
	RETVAL=clist->sort_column;
    OUTPUT:
	RETVAL


GdkWindow *
clist_window (GtkCList * clist)
    CODE:
	RETVAL = clist->clist_window;
    OUTPUT:
	RETVAL

int
rows(GtkCList* clist)
    CODE:
	RETVAL=clist->rows;
    OUTPUT:
	RETVAL

int
columns(GtkCList*clist)
    CODE:
	RETVAL=clist->columns;
    OUTPUT:
	RETVAL

GtkSelectionMode
selection_mode (GtkCList*clist)
    CODE:
	RETVAL=clist->selection_mode;
    OUTPUT:
	RETVAL

=for apidoc
=for signature @indices = $clist->selection
Returns a list of the row numbers of the current selection.
=cut
void
selection (GtkCList* clist)
    PPCODE:
	{
		GList * selection = clist->selection;
		while(selection) {
			EXTEND(sp, 1);
			PUSHs(sv_2mortal(newSViv(GPOINTER_TO_INT(selection->data))));
			selection=g_list_next(selection);
		}
	}

=for apidoc
=for signature @rows = $clist->row_list
Returns a list of GtkCListRow.
=cut
void
row_list (clist)
	GtkCList*	clist
	PPCODE:
	{
		GList * row_list = clist->row_list;
		while(row_list) {
			EXTEND(sp, 1);
			PUSHs(sv_2mortal(newSVGtkCListRow(row_list->data)));
			row_list=g_list_next(row_list);
		}

	}




## regular api functions

GtkWidget * gtk_clist_new (class, gint columns)
    CODE:
	warn_deprecated ("Gtk2::CList is deprecated, use Gtk2::ListStore and Gtk2::TreeView instead");
	RETVAL = gtk_clist_new (columns);
    OUTPUT:
	RETVAL

GtkWidget *
gtk_clist_new_with_titles (class, gchar * title, ...)
    PREINIT:
	int columns, i;
	gchar ** titles = NULL;
    CODE:
	warn_deprecated ("Gtk2::CList is deprecated, use Gtk2::ListStore and Gtk2::TreeView instead");
	columns = items - 1;
	titles = g_new0 (gchar*, columns);
	for (i = 1 ; i < items ; ++i)
		titles[i-1] = SvGChar (ST (i));
	RETVAL = gtk_clist_new_with_titles (columns, titles);
	g_free (titles);
    OUTPUT:
	RETVAL


void gtk_clist_set_hadjustment (GtkCList *clist, GtkAdjustment *adjustment);

void gtk_clist_set_vadjustment (GtkCList *clist, GtkAdjustment *adjustment);

GtkAdjustment* gtk_clist_get_hadjustment (GtkCList *clist);

GtkAdjustment* gtk_clist_get_vadjustment (GtkCList *clist);

void gtk_clist_set_shadow_type (GtkCList *clist, GtkShadowType type);

void gtk_clist_set_selection_mode (GtkCList *clist, GtkSelectionMode mode);

void gtk_clist_set_reorderable (GtkCList *clist, gboolean reorderable);

void gtk_clist_set_use_drag_icons (GtkCList *clist, gboolean use_icons);

void gtk_clist_set_button_actions (GtkCList *clist, guint button, GtkButtonAction button_actions);

void gtk_clist_freeze (GtkCList *clist);

void gtk_clist_thaw   (GtkCList *clist);

void gtk_clist_column_titles_show (GtkCList *clist);

void gtk_clist_column_titles_hide (GtkCList *clist);

void gtk_clist_column_title_active   (GtkCList *clist, gint      column);

void gtk_clist_column_title_passive  (GtkCList *clist, gint      column);

void gtk_clist_column_titles_active  (GtkCList *clist);

void gtk_clist_column_titles_passive (GtkCList *clist);

void gtk_clist_set_column_title (GtkCList *clist, gint column, const gchar *title);

gchar * gtk_clist_get_column_title (GtkCList *clist, gint column);

void gtk_clist_set_column_widget (GtkCList  *clist, gint column, GtkWidget *widget);

GtkWidget * gtk_clist_get_column_widget (GtkCList *clist, gint column);

void gtk_clist_set_column_justification (GtkCList *clist, gint column, GtkJustification  justification);

void gtk_clist_set_column_visibility (GtkCList *clist, gint column, gboolean  visible);

void gtk_clist_set_column_resizeable (GtkCList *clist, gint column, gboolean  resizeable);

void gtk_clist_set_column_auto_resize (GtkCList *clist, gint column, gboolean auto_resize);

gint gtk_clist_columns_autosize (GtkCList *clist);

gint gtk_clist_optimal_column_width (GtkCList *clist, gint column);

void gtk_clist_set_column_width (GtkCList *clist, gint column, gint width);

void gtk_clist_set_column_min_width (GtkCList *clist, gint column, gint min_width);

void gtk_clist_set_column_max_width (GtkCList *clist, gint column, gint max_width);

void gtk_clist_set_row_height (GtkCList *clist, guint height);

void gtk_clist_moveto (GtkCList *clist, gint row, gint column, gfloat row_align, gfloat col_align);

GtkVisibility gtk_clist_row_is_visible (GtkCList *clist, gint row);

GtkCellType gtk_clist_get_cell_type (GtkCList *clist, gint row, gint column);

void gtk_clist_set_text (GtkCList *clist, gint row, gint column, const gchar *text);

gchar *
gtk_clist_get_text (GtkCList  *clist, gint row, gint column)
    CODE:
	gtk_clist_get_text (clist, row, column, &RETVAL);
    OUTPUT:
	RETVAL

void gtk_clist_set_pixmap (GtkCList  *clist, gint row, gint column, GdkPixmap *pixmap, GdkBitmap_ornull *mask);

void
gtk_clist_get_pixmap (GtkCList *clist, gint row, gint column)
    PREINIT:
	GdkPixmap *pixmap;
	GdkBitmap *mask;
    PPCODE:
	if (gtk_clist_get_pixmap (clist, row, column, &pixmap, (GIMME == G_ARRAY) ?&mask: NULL)) {
		XPUSHs (sv_2mortal (newSVGdkPixmap (pixmap)));
		if (mask)
			XPUSHs (sv_2mortal (newSVGdkBitmap (mask)));
	}

void gtk_clist_set_pixtext (GtkCList *clist, gint row, gint column, const gchar *text, guint8 spacing, GdkPixmap *pixmap, GdkBitmap_ornull *mask);

void
gtk_clist_get_pixtext (GtkCList *clist, gint row, gint column)
    PREINIT:
	gchar *text = NULL;
	guint8 spacing;
	GdkPixmap *pixmap = NULL;
	GdkBitmap *mask = NULL;
    PPCODE:
	if (gtk_clist_get_pixtext(clist, row, column, &text, &spacing, &pixmap, &mask)) {
		EXTEND (sp, 4);
		if (text)
			PUSHs (sv_2mortal (newSVpv (text, 0)));
		else
			PUSHs (sv_2mortal (newSVsv (&PL_sv_undef)));
		PUSHs (sv_2mortal (newSViv (spacing)));
		if (pixmap)
			PUSHs (sv_2mortal (newSVGdkPixmap (pixmap)));
		else
			PUSHs (sv_2mortal (newSVsv (&PL_sv_undef)));
		if (mask)
			PUSHs (sv_2mortal (newSVGdkBitmap (mask)));
		else
			PUSHs (sv_2mortal (newSVsv (&PL_sv_undef)));
	}

void gtk_clist_set_foreground (GtkCList *clist, gint row, GdkColor *color);

void gtk_clist_set_background (GtkCList *clist, gint row, GdkColor *color);

void gtk_clist_set_cell_style (GtkCList *clist, gint row, gint column, GtkStyle *style);

GtkStyle *gtk_clist_get_cell_style (GtkCList *clist, gint row, gint column);

void gtk_clist_set_row_style (GtkCList *clist, gint row, GtkStyle *style);

GtkStyle *gtk_clist_get_row_style (GtkCList *clist, gint row);

void gtk_clist_set_shift (GtkCList *clist, gint row, gint column, gint vertical, gint horizontal);

void gtk_clist_set_selectable (GtkCList *clist, gint row, gboolean selectable);

gboolean gtk_clist_get_selectable (GtkCList *clist, gint row);

gint gtk_clist_prepend (GtkCList *clist, gchar *text, ...)
    ALIAS:
	append = 1
    PREINIT:
	gchar ** strv = NULL;
	int i;
    CODE:
	strv = g_new0 (gchar*, items);
	for (i = 1 ; i < items ; i++)
		strv[i-1] = SvGChar (ST (i));
	if (ix == 1)
		RETVAL = gtk_clist_append (clist, strv);
	else
		RETVAL = gtk_clist_prepend (clist, strv);
	g_free (strv);
    OUTPUT:
	RETVAL

gint gtk_clist_insert (GtkCList *clist, gint row, gchar *text, ...);
    PREINIT:
	gchar ** strv = NULL;
	int i;
    CODE:
	strv = g_new0 (gchar*, items-1);
	for (i = 2 ; i < items ; i++)
		strv[i-2] = SvGChar (ST (i));
	RETVAL = gtk_clist_insert (clist, row, strv);
	g_free (strv);
    OUTPUT:
	RETVAL

void gtk_clist_remove (GtkCList *clist, gint row);

void gtk_clist_set_row_data (GtkCList *clist, gint row, SV * data)
    PREINIT:
	SV * real_data;
    CODE:
	if (!SvROK (data))
		croak ("Data must be a reference");
	/* we can't store a pointer to the reference, as the references are
	 * usually temporary.  instead, store a pointer to the thing to which
	 * the reference ... refers.  NOTE: we can't use gperl_sv_copy() here,
	 * because it may not be a plain SV.  diddle with the refcount 
	 * directly, instead. */
	real_data = (SV*) SvRV (data);
	SvREFCNT_inc (real_data);
	gtk_clist_set_row_data_full (clist, row, real_data, row_data_destroy);

SV * gtk_clist_get_row_data (GtkCList *clist, gint row)
    PREINIT:
	SV * sv;
    CODE:
	sv = gtk_clist_get_row_data (clist, row);
	RETVAL = sv ? newRV_inc (sv) : newSVsv (&PL_sv_undef);
    OUTPUT:
	RETVAL

gint gtk_clist_find_row_from_data (GtkCList *clist, SV * data);
    PREINIT:
	SV * sv;
    CODE:
	sv = (SV*)SvRV (data);
	if (!sv)
		croak("Data must be a reference");
	RETVAL = gtk_clist_find_row_from_data(clist, sv);
    OUTPUT:
	RETVAL

void gtk_clist_select_row (GtkCList *clist, gint row, gint column);

void gtk_clist_unselect_row (GtkCList *clist, gint row, gint column);

void gtk_clist_undo_selection (GtkCList *clist);

void gtk_clist_clear (GtkCList *clist);

##gint gtk_clist_get_selection_info (GtkCList *clist, gint x, gint y)
void gtk_clist_get_selection_info (GtkCList *clist, gint x, gint y)
    PREINIT:
	gint row, column;
    PPCODE:
	if (gtk_clist_get_selection_info (clist, x, y, &row, &column)) {
		EXTEND (SP, 2);
		PUSHs (sv_2mortal (newSViv (row)));
		PUSHs (sv_2mortal (newSViv (column)));
	}

void gtk_clist_select_all (GtkCList *clist);

void gtk_clist_unselect_all (GtkCList *clist);

void gtk_clist_swap_rows (GtkCList *clist, gint row1, gint row2);

void gtk_clist_row_move (GtkCList *clist, gint source_row, gint dest_row);

void gtk_clist_set_compare_func (GtkCList *clist, SV * handler, SV * data)
    PREINIT:
	GPerlCallback * callback;
    CODE:
	callback = gperl_callback_new (handler, data, 0, NULL, 0);
	gtk_clist_set_compare_func (clist, my_clist_compare);
	gtk_object_set_data_full(GTK_OBJECT(clist), "_perl_sort_cb",
	                         callback,
				 (GDestroyNotify)gperl_callback_destroy);


void gtk_clist_set_sort_column (GtkCList *clist, gint column);

void gtk_clist_set_sort_type (GtkCList *clist, GtkSortType sort_type);

void gtk_clist_sort (GtkCList *clist);

void gtk_clist_set_auto_sort (GtkCList *clist, gboolean  auto_sort);

