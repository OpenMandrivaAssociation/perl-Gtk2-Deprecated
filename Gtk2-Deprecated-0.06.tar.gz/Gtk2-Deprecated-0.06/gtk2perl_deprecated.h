#ifndef __GTK2PERL_DEPRECATED_H__
#define __GTK2PERL_DEPRECATED_H__

#undef GTK_DISABLE_DEPRECATED
#define GTK_ENABLE_BROKEN

#include <gtk2perl.h>

#ifndef GTK_TYPE_CTREE_ROW
  /* we must provide our own boxed type for CTreeRow */
  GType gtk2perl_ctree_row_get_type (void) G_GNUC_CONST;
# define GTK_TYPE_CTREE_ROW	(gtk2perl_ctree_row_get_type ())
#endif

#include "gtk2perl_deprecated-autogen.h"

#define warn_deprecated(str)	warn(str)

SV * newSVGtkCListRow (GtkCListRow * row);
GtkCListRow * SvGtkCListRow (SV * sv);

#endif /* __GTK2PERL_DEPRECATED_H__ */
